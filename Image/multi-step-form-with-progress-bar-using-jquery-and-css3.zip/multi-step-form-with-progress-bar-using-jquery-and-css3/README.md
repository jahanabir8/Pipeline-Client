# Multi Step Form with Progress Bar using jQuery and CSS3

A Pen created on CodePen.io. Original URL: [https://codepen.io/Creative_Srijon/pen/EKwRgO](https://codepen.io/Creative_Srijon/pen/EKwRgO).

Got long forms on your website ? Break them up into smaller logical sections and convert it into a multi-step form with a cool progress bar. Could work for lengthy processes like registration, checkout, profile fillups, 2-factor authentication logins, etc.

Forked from [Atakan Goktepe](http://codepen.io/atakan/)'s Pen [Multi Step Form with Progress Bar using jQuery and CSS3](http://codepen.io/atakan/pen/gqbIz/).